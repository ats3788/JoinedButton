// JoinedButton.h
// Hello I wrote a class for Fun and to make it easyier to
// work with Button. Yo can Easy adopt it for yor needs

#ifndef _JOINEDBUTTON_h
#define _JOINEDBUTTON_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <Adafruit_GFX.h>  // 
#include <TouchScreen.h>   //
#include <MCUFRIEND_kbv.h>

#define TEST
#define Background ILI9341_ANTIQUEWHITE
#define X1 50
#define X2 X1+90
#define X3 X2+90

#define Y1 50
#define Y2 Y1+40
#define Y3 Y2+40
#define Y4 Y3+40

#define MINPRESSURE 200
#define MAXPRESSURE 1000

class JoinedButtonClass
{
private:
	const int TS_LEFT = 907, TS_RT = 136, TS_TOP = 942, TS_BOT = 139;
	// ALL Touch panels and wiring is DIFFERENT
// copy-paste results from TouchScreen_Calibr_native.ino
	const int XP = 6, XM = A2, YP = A1, YM = 7; //ID=0x9341
	
	TouchScreen *_ts;
	Adafruit_GFX * _gfx;
	int pixel_x, pixel_y;     //Touch_getXY() updates global vars
	char Buffer[20];

	bool update_button(Adafruit_GFX_Button *b, bool down);
	
	bool Touch_getXY(void);
	
 public:
	void init( TouchScreen* ts, Adafruit_GFX* gfx);
	bool update_button_list(Adafruit_GFX_Button **pb);
};

extern Adafruit_GFX_Button btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0, btn_Enter;
extern Adafruit_GFX_Button *buttons[];
extern JoinedButtonClass * JoinedButton;

#endif

