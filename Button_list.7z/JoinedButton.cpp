
#include "JoinedButton.h"
Adafruit_GFX_Button btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0, btn_Enter;
// This is importand to notice Because of the small SDRam we a only to enable the first five buttons
// When I'm back from my vacation I will Test if its running with the Mega 2560
Adafruit_GFX_Button *buttons[] = { &btn_1, &btn_2, &btn_3, &btn_4, &btn_5, nullptr };


/* update the state of a button and redraw as reqd
 *
 * main program can use isPressed(), justPressed() etc
 */

bool JoinedButtonClass::update_button(Adafruit_GFX_Button *b, bool down)
{
	b->press(down && b->contains(pixel_x, pixel_y));
	if (b->justReleased())
		b->drawButton(false);
	if (b->justPressed())
		b->drawButton(true);
	return down;
}

/* most screens have different sets of buttons
 * life is easier if you process whole list in one go
 */
bool JoinedButtonClass::update_button_list(Adafruit_GFX_Button **pb)
{
	bool down = Touch_getXY();
	for (int i = 0; pb[i] != nullptr; i++) {
		update_button(pb[i], down);
	}
	return down;
}


void JoinedButtonClass::init( TouchScreen* ts, Adafruit_GFX* gfx)
{


_ts = ts;
_gfx = gfx;

btn_1.initButton(_gfx, X1, Y1, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "1", 2);
btn_2.initButton(_gfx, X2, Y1, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "2", 2);
btn_3.initButton(_gfx, X3, Y1, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "3", 2);

btn_4.initButton(_gfx, X1, Y2, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "4", 2);
btn_5.initButton(_gfx, X2, Y2, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "5", 2);
btn_6.initButton(_gfx, X3, Y2, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "6", 2);

btn_7.initButton(_gfx, X1, Y3, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "7", 2);
btn_8.initButton(_gfx, X2, Y3, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "8", 2);
btn_9.initButton(_gfx, X3, Y3, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "9", 2);

btn_0.initButton(_gfx, X1, Y4, 80, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "0", 2);
btn_Enter.initButton(_gfx, X3 - 45, Y4, 170, 30, ILI9341_WHITE, ILI9341_GREEN, ILI9341_AQUAMARINE, "Enter", 2);

btn_1.drawButton(false);
btn_2.drawButton(false);
btn_3.drawButton(false);
btn_4.drawButton(false);
btn_5.drawButton(false);
btn_6.drawButton(false);
btn_7.drawButton(false);
btn_8.drawButton(false);
btn_9.drawButton(false);
btn_0.drawButton(false);

btn_Enter.drawButton(false);


_gfx->fillRect(40, 5, 90, 20, ILI9341_SALMON);

}




bool JoinedButtonClass::Touch_getXY(void)
{
	
	TSPoint p = _ts->getPoint();
	pinMode(YP, OUTPUT);      //restore shared pins
	pinMode(XM, OUTPUT);
	digitalWrite(YP, HIGH);   //because _gfx-> control pins
	digitalWrite(XM, HIGH);

	bool pressed = (p.z > MINPRESSURE && p.z < MAXPRESSURE);
	if (pressed) {

		// I had to do this way because, the Screen works in Mode 1 Landscape
		pixel_y = map(p.x, TS_LEFT, TS_RT, 0, _gfx->height()); //.kbv makes sense to me
		pixel_x = _gfx->width() - (map(p.y, TS_TOP, TS_BOT, 0, _gfx->width()));
		// This is just for Testing Just  Change the dfine in the Header !!!!!
#ifdef TEST
		_gfx->drawPixel(pixel_x, pixel_y, ILI9341_RED);
		//  map(long x, long in_min, long in_max, long out_min, long out_max)
		//	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
		// Just for Testing
		sprintf(Buffer, "X = %d - Y = %d", pixel_x, pixel_y);
		Serial.print(Buffer);
#endif // TEST
	}

	return pressed;
}




JoinedButtonClass * JoinedButton;

